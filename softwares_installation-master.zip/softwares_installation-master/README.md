# jenkins

How to remove jenkins from Ubuntu/Centos ?

sudo service jenkins stop

Centos : sudo yum remove jenkins

Ubuntu :sudo apt remove jenkins
